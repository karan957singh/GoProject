# golang-authentication


To start this app, perform the following step in order

1. Clone this repo to your machine 
2. cd into the project folder
3.  enter `go run main.go` to start server
